<?php

namespace App\View\Components\Forms;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;
use Illuminate\View\Component;

class Input extends Component
{
    public ?string $modelBinding = null;

    public ?string $htmlId = null;

    public function __construct(
        public ?string $id = null,
        public ?string $name = null,
        public ?string $type = 'text',
        public ?string $value = null,
        public ?string $label = null,
        public bool $required = false,
        public bool $disabled = false,
        public bool $readonly = false,
        public ?string $helper = null,
        public bool $allowToPeak = true,
        public bool $copyable = false,
        public bool $isMultiline = false,
        public string $defaultClass = 'input',
        public string $autocomplete = 'off',
        public ?int $minlength = null,
        public ?int $maxlength = null,
        public bool $autofocus = false,
        public ?string $canGate = null,
        public mixed $canResource = null,
        public bool $autoDisable = true,
        public bool $loading = false,
        public string $loadingText = 'Loading...',
    ) {
        // Handle authorization-based disabling
        if ($this->canGate && $this->canResource && $this->autoDisable) {
            $hasPermission = Gate::allows($this->canGate, $this->canResource);

            if (! $hasPermission) {
                $this->disabled = true;
            }
        }
    }

    public function render(): View|Closure|string
    {
        // Store original ID for wire:model binding (property name)
        $this->modelBinding = $this->id;

        if (is_null($this->id)) {
            $this->id = new_public_id();
            // Don't create wire:model binding for auto-generated IDs
            $this->modelBinding = 'null';
        }
        // Generate unique HTML ID by adding random suffix
        // This prevents duplicate IDs when multiple forms are on the same page
        if ($this->modelBinding && $this->modelBinding !== 'null') {
            // Use original ID with random suffix for uniqueness
            $uniqueSuffix = new_public_id();
            $this->htmlId = $this->modelBinding.'-'.$uniqueSuffix;
        } else {
            $this->htmlId = (string) $this->id;
        }

        if (is_null($this->name)) {
            $this->name = $this->modelBinding !== 'null' ? $this->modelBinding : (string) $this->id;
        }
        // Durable class (not type-attr based): Alpine may toggle type to "text" when revealing,
        // and settings-workspace CSS otherwise overrides utility padding-right.
        $hasPeek = $this->type === 'password' && $this->allowToPeak;
        if ($hasPeek) {
            $this->defaultClass = $this->defaultClass.' input-with-password-toggle';
        }
        if ($this->copyable) {
            // Reserve clearance for a single copy button, or for both the peek eye
            // and the copy button when the field is a maskable password.
            $this->defaultClass = $this->defaultClass.($hasPeek ? ' input-with-copy-and-peek' : ' input-with-copy-button');
        }

        // $this->label = Str::title($this->label);
        return view('components.forms.input');
    }
}
