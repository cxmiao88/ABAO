<?php

namespace App\View\Components\Forms;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\Component;

class EnvVarInput extends Component
{
    public ?string $modelBinding = null;

    public ?string $htmlId = null;

    public array $scopeUrls = [];

    public function __construct(
        public ?string $id = null,
        public ?string $name = null,
        public ?string $type = 'text',
        public ?string $value = null,
        public ?string $label = null,
        public bool $required = false,
        public bool $disabled = false,
        public bool $readonly = false,
        public ?string $helper = null,
        public bool $allowToPeak = true,
        public string $defaultClass = 'input',
        public string $autocomplete = 'off',
        public ?int $minlength = null,
        public ?int $maxlength = null,
        public bool $autofocus = false,
        public ?string $canGate = null,
        public mixed $canResource = null,
        public bool $autoDisable = true,
        public array $availableVars = [],
        public bool $hasVaultSource = false,
        public ?string $projectUuid = null,
        public ?string $environmentUuid = null,
        public ?string $serverUuid = null,
    ) {
        // Handle authorization-based disabling
        if ($this->canGate && $this->canResource && $this->autoDisable) {
            $hasPermission = Gate::allows($this->canGate, $this->canResource);

            if (! $hasPermission) {
                $this->disabled = true;
            }
        }
    }

    public function render(): View|Closure|string
    {
        // Store original ID for wire:model binding (property name)
        $this->modelBinding = $this->id;

        if (is_null($this->id)) {
            $this->id = new_public_id();
            // Don't create wire:model binding for auto-generated IDs
            $this->modelBinding = 'null';
        }
        // Generate unique HTML ID by adding random suffix
        // This prevents duplicate IDs when multiple forms are on the same page
        if ($this->modelBinding && $this->modelBinding !== 'null') {
            // Use original ID with random suffix for uniqueness
            $uniqueSuffix = new_public_id();
            $this->htmlId = $this->modelBinding.'-'.$uniqueSuffix;
        } else {
            $this->htmlId = (string) $this->id;
        }

        if (is_null($this->name)) {
            $this->name = $this->modelBinding !== 'null' ? $this->modelBinding : (string) $this->id;
        }

        // Durable class (not type-attr based): Alpine may toggle type to "text" when revealing,
        // and settings-workspace CSS otherwise overrides utility padding-right.
        if ($this->type === 'password' && $this->allowToPeak) {
            $this->defaultClass = $this->defaultClass.' input-with-password-toggle';
        }

        $this->scopeUrls = [
            'team' => route('shared-variables.team.index'),
            'project' => route('shared-variables.project.index'),
            'environment' => $this->projectUuid && $this->environmentUuid
                ? route('shared-variables.environment.show', [
                    'project_uuid' => $this->projectUuid,
                    'environment_uuid' => $this->environmentUuid,
                ])
                : route('shared-variables.environment.index'),
            'server' => $this->serverUuid
                ? route('shared-variables.server.show', ['server_uuid' => $this->serverUuid])
                : route('shared-variables.server.index'),
            'default' => route('shared-variables.index'),
        ];

        return view('components.forms.env-var-input');
    }
}
