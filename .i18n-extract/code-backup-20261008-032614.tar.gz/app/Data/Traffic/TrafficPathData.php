<?php

namespace App\Data\Traffic;

use Spatie\LaravelData\Data;

class TrafficPathData extends Data
{
    public function __construct(
        public string $path,
        public int $requests,
        public int $bytesOut,
        public int $s4xx,
        public int $s5xx,
        public float $p50,
        public float $p95,
        // Owning app key (Sentinel returns this per path row so the UI can show the
        // domain). Empty on older Sentinel builds that predate the field.
        public string $app = '',
    ) {}

    public static function fromSentinel(array $row): self
    {
        return new self(
            path: (string) data_get($row, 'path', ''),
            requests: (int) data_get($row, 'requests', 0),
            bytesOut: (int) data_get($row, 'bytes_out', 0),
            s4xx: (int) data_get($row, 's4xx', 0),
            s5xx: (int) data_get($row, 's5xx', 0),
            p50: (float) data_get($row, 'p50', 0.0),
            p95: (float) data_get($row, 'p95', 0.0),
            app: (string) data_get($row, 'app', ''),
        );
    }
}
